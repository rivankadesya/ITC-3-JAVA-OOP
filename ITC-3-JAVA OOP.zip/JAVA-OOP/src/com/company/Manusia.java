package com.company;

public class Manusia {

    String nama;
    String ktp;
    int umur;

    //overloading
    //overriding

    public Manusia(String nama) {
        this.nama = nama;

    }
    public void makan(){
        System.out.println("sedang makan");
    }
    //ini overloading
    public void makan(String nama){
        System.out.println(nama + "sedang makan");
    }
    public void makan(String nama, int umur){
        System.out.println(nama + "sedang makan");
    }

}
