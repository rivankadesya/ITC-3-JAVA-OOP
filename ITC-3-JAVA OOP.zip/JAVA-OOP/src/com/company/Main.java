package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here

//        Mahasiswa daru = new Mahasiswa("anjar", "123180056", 4.0);
////        daru.nama = "Aka Allyandaru imo";
////        daru.nim = "123180054";
////        daru.IPK = 4.0;
//
//        daru.setNama("aka allyandaru imo");
//        daru.setNim("123180053");
//        daru.setIPK(4.0);
//
////        System.out.println("Nama =" + daru.nama);
////        System.out.println("Nim =" + daru.nim);
////        System.out.println("ipk =" + daru.IPK);
//
//        System.out.println("Nama =" + daru.getNama());
//        System.out.println("Nim =" + daru.getNim());
//        System.out.println("IPK =" + daru.getIPK());
//
//        daru.belajar();
//        daru.doTugas();

        Manusia manusia = new Manusia("isnaini khairiah");
        Mahasiswa mahasiswa = new Mahasiswa("Riris", "123190002",4.0);

        System.out.println("nama : "+mahasiswa.getNama());
        mahasiswa.ktp = "243243543";

        manusia.makan("anjar ");

        mahasiswa.berjoget("gerakan tiktok");

    }
}
