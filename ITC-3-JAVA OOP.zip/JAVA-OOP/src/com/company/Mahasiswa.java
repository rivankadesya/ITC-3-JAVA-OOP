package com.company;

public class Mahasiswa extends Manusia implements Bernyanyi{
    private String nim;
    private double IPK;


    public Mahasiswa(String nama, String nim, double IPK) {
        super(nama);
        this.nim = nim;
        this.IPK = IPK;

    }

    public String getNama() {
        return super.nama;
    }

    public void setNama(String nama) {
        super.nama = nama;
    }

    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public double getIPK() {
        return IPK;
    }

    public void setIPK(double IPK) {
        this.IPK = IPK;
    }

    //method
    void belajar() {
        System.out.println("sedang belajar");
    }

    void doTugas() {
        System.out.println("ngerjain tugas");

    }

    @Override
    public void bernada() {
        System.out.println(nama+"SEDANG BERNYANYI");
    }

    @Override
    public void berjoget(String gerakan) {
        System.out.println("jogeet"+gerakan);

    }
}
