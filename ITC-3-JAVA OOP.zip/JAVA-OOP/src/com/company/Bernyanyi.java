package com.company;

public interface Bernyanyi {
    void bernada();
    void berjoget(String gerakan);
}
